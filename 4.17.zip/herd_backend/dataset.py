import json
import torch
from torch.utils.data import Dataset


class HerbDataset(Dataset):
    def __init__(self, path_or_data):
        if isinstance(path_or_data, str):
            with open(path_or_data, 'r') as f:
                self.data = json.load(f)
        else:
            self.data = path_or_data

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        x = self.data[idx]

        return {
            "compound_ids": list(map(int, x["compound_ids"])),
            "target_ids": list(map(int, x["target_ids"])),
            "feature_vector": list(map(float, x["feature_vector"])),
            "interaction_matrix": x["interaction_matrix"],
            "label": list(map(float, x["label"]))
        }


# 处理变长数据
def collate_fn(batch):
    batch_size = len(batch)

    max_nc   = max(len(x["compound_ids"]) for x in batch)
    max_nt   = max(len(x["target_ids"])   for x in batch)
    feat_dim = len(batch[0]["feature_vector"])

    compound_ids = torch.zeros(batch_size, max_nc, dtype=torch.long)
    target_ids   = torch.zeros(batch_size, max_nt, dtype=torch.long)
    feature_vecs = torch.zeros(batch_size, feat_dim)
    interaction  = torch.zeros(batch_size, max_nc, max_nt)
    labels       = torch.zeros(batch_size, 5)

    for i, x in enumerate(batch):
        nc = len(x["compound_ids"])
        nt = len(x["target_ids"])

        compound_ids[i, :nc] = torch.tensor(x["compound_ids"])
        target_ids[i,   :nt] = torch.tensor(x["target_ids"])
        feature_vecs[i]      = torch.tensor(x["feature_vector"])

        inter = torch.tensor(x["interaction_matrix"])
        interaction[i, :nc, :nt] = inter

        labels[i] = torch.tensor(x["label"])

    return compound_ids, target_ids, interaction, feature_vecs, labels