import torch
import torch.nn as nn


class HerbModel(nn.Module):
    """Per-label binary classifier: 5 independent heads (300→512→256→1 each)."""
    def __init__(self, feat_dim=300, num_labels=5):
        super().__init__()
        self.num_labels = num_labels
        self.heads = nn.ModuleList()
        for _ in range(num_labels):
            self.heads.append(nn.Sequential(
                nn.Linear(feat_dim, 512),
                nn.BatchNorm1d(512),
                nn.ReLU(),
                nn.Dropout(0.2),
                nn.Linear(512, 256),
                nn.BatchNorm1d(256),
                nn.ReLU(),
                nn.Dropout(0.1),
                nn.Linear(256, 1),
            ))

    def forward(self, feature_vecs):
        outs = [head(feature_vecs) for head in self.heads]
        return torch.cat(outs, dim=1)  # (B, num_labels)


class AsymmetricLoss(nn.Module):
    """ASL from ICCV 2021 (Alibaba-MIIL). Operates on logits."""
    def __init__(self, gamma_neg=4, gamma_pos=1, clip=0.05, eps=1e-8):
        super().__init__()
        self.gamma_neg = gamma_neg
        self.gamma_pos = gamma_pos
        self.clip = clip
        self.eps = eps

    def forward(self, x, y):
        xs_pos = torch.sigmoid(x)
        xs_neg = 1 - xs_pos

        if self.clip is not None and self.clip > 0:
            xs_neg = (xs_neg + self.clip).clamp(max=1)

        los_pos = y * torch.log(xs_pos.clamp(min=self.eps))
        los_neg = (1 - y) * torch.log(xs_neg.clamp(min=self.eps))
        loss = los_pos + los_neg

        if self.gamma_neg > 0 or self.gamma_pos > 0:
            pt0 = xs_pos * y
            pt1 = xs_neg * (1 - y)
            pt = pt0 + pt1
            one_sided_gamma = self.gamma_pos * y + self.gamma_neg * (1 - y)
            one_sided_w = torch.pow(1 - pt, one_sided_gamma)
            loss *= one_sided_w

        return -loss.sum() / x.size(0)