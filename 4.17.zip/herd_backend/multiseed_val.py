"""Multi-seed validation of top augmentation approaches."""
import os, sys, random, json, numpy as np, torch
os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, '.')
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold
from model import HerbModel, AsymmetricLoss

def mixup_batch(fv, lb, alpha=0.2):
    if alpha <= 0: return fv, lb
    lam = np.random.beta(alpha, alpha)
    idx = torch.randperm(fv.size(0))
    return lam*fv+(1-lam)*fv[idx], lam*lb+(1-lam)*lb[idx]

with open('dataset/output/all_herbs.json','r',encoding='utf-8') as f:
    all_data = json.load(f)
features = np.array([d['feature_vector'] for d in all_data], dtype=np.float32)
labels = np.array([d['label'] for d in all_data], dtype=np.float32)
label_strs = [''.join(str(int(v)) for v in d['label']) for d in all_data]

def run_one(seed, drop_p=0.0, add_p=0.0):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    torch.backends.cudnn.deterministic=True; torch.backends.cudnn.benchmark=False
    device=torch.device('cpu')
    skf=StratifiedKFold(n_splits=5, shuffle=True, random_state=seed)
    fold_aucs=[]
    for fold,(ti,vi) in enumerate(skf.split(all_data, label_strs)):
        tf,tl=features[ti],labels[ti]; vf,vl=features[vi],labels[vi]
        avp=np.zeros((len(vi),5))
        for li in range(5):
            torch.manual_seed(seed+fold*100+li*7)
            np.random.seed(seed+fold*100+li*7)
            random.seed(seed+fold*100+li*7)
            trf=torch.tensor(tf,dtype=torch.float32)
            trl=torch.tensor(tl[:,li:li+1],dtype=torch.float32)
            vaf=torch.tensor(vf,dtype=torch.float32)
            val_=torch.tensor(vl[:,li:li+1],dtype=torch.float32)
            tloader=DataLoader(TensorDataset(trf,trl),batch_size=32,shuffle=True,drop_last=True)
            vloader=DataLoader(TensorDataset(vaf,val_),batch_size=32)
            model=HerbModel(num_labels=1).to(device)
            crit=AsymmetricLoss(gamma_neg=4,gamma_pos=1,clip=0.05)
            opt=torch.optim.AdamW(model.parameters(),lr=1e-3,weight_decay=5e-4)
            sch=torch.optim.lr_scheduler.CosineAnnealingLR(opt,T_max=200,eta_min=1e-6)
            ba,cn,bs=0.0,0,None
            for ep in range(200):
                model.train()
                for fv,lb in tloader:
                    fv,lb=fv.to(device),lb.to(device)
                    if drop_p>0:
                        mask=(torch.rand_like(fv)>drop_p).float(); fv=fv*mask
                    if add_p>0:
                        am=(torch.rand_like(fv)<add_p)&(fv==0); fv=torch.clamp(fv+am.float(),0,1)
                    fv,lb=mixup_batch(fv,lb,0.2); lb=lb*0.95+0.025
                    loss=crit(model(fv),lb); opt.zero_grad(); loss.backward()
                    torch.nn.utils.clip_grad_norm_(model.parameters(),1.0); opt.step()
                sch.step()
                model.eval(); vps,vls=[],[]
                with torch.no_grad():
                    for fv,lb in vloader:
                        vps.append(torch.sigmoid(model(fv)).numpy()); vls.append(lb.numpy())
                vp_,vl_=np.concatenate(vps),np.concatenate(vls)
                try: va=roc_auc_score(vl_,vp_)
                except: va=0.0
                if va>ba: ba=va;cn=0;bs={k:v.clone() for k,v in model.state_dict().items()}
                else: cn+=1
                if cn>=30: break
            if bs: model.load_state_dict(bs)
            model.eval(); vps=[]
            with torch.no_grad():
                for fv,_ in vloader: vps.append(torch.sigmoid(model(fv)).numpy())
            avp[:,li]=np.concatenate(vps).flatten()
        try: fa=roc_auc_score(vl,avp,average='macro')
        except: fa=0.0
        fold_aucs.append(fa)
    return np.mean(fold_aucs)

configs = [
    ('Baseline',    0.0,  0.0),
    ('Drop15',      0.15, 0.0),
    ('Drop30',      0.30, 0.0),
    ('DropAdd15_1', 0.15, 0.01),
    ('DropAdd20_1', 0.20, 0.01),
]
seeds = [42, 123, 456, 789, 2024]

header = f"{'Method':<18}"
for s in seeds:
    header += f"seed={s:<5} "
header += "  mean   std"
print(header)
print('-' * 80)

for name, dp, ap in configs:
    aucs = [run_one(s, dp, ap) for s in seeds]
    m, std = np.mean(aucs), np.std(aucs)
    row = f"{name:<18}"
    for a in aucs:
        row += f"{a:.4f}  "
    row += f"{m:.4f}  {std:.4f}"
    print(row)
