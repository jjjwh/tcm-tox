"""
Rerun all experiments with venv Python (PyTorch 2.11.0).
Baseline: AUC = 0.6241 ± 0.0260
"""
import os, sys, random, json, copy
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import f1_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
from model import HerbModel, AsymmetricLoss

CORR = np.array([
    [1.000, 0.255, 0.202, -0.006, 0.233],
    [0.255, 1.000, 0.493, -0.075, 0.212],
    [0.202, 0.493, 1.000, -0.070, 0.251],
    [-0.006, -0.075, -0.070, 1.000, -0.081],
    [0.233, 0.212, 0.251, -0.081, 1.000],
])

def find_best_thresholds(y_true, y_prob):
    thresholds = []
    for i in range(y_prob.shape[1]):
        best_t, best_f1 = 0.5, 0
        for t in np.linspace(0.05, 0.9, 18):
            pred = (y_prob[:, i] > t).astype(int)
            f1 = f1_score(y_true[:, i], pred, zero_division=0)
            if f1 > best_f1:
                best_f1, best_t = f1, t
        thresholds.append(best_t)
    return thresholds

def mixup_batch(fv, lb, alpha=0.2):
    if alpha <= 0: return fv, lb
    lam = np.random.beta(alpha, alpha)
    idx = torch.randperm(fv.size(0))
    return lam*fv+(1-lam)*fv[idx], lam*lb+(1-lam)*lb[idx]

def load_data():
    with open(os.path.join(BASE_DIR, "dataset/output/all_herbs.json"), 'r', encoding='utf-8') as f:
        all_data = json.load(f)
    features = np.array([d["feature_vector"] for d in all_data], dtype=np.float32)
    labels = np.array([d["label"] for d in all_data], dtype=np.float32)
    label_strs = [''.join(str(int(v)) for v in d['label']) for d in all_data]
    return all_data, features, labels, label_strs

def make_head(in_dim=300, h1=512, h2=256):
    return nn.Sequential(
        nn.Linear(in_dim, h1), nn.BatchNorm1d(h1), nn.ReLU(), nn.Dropout(0.2),
        nn.Linear(h1, h2), nn.BatchNorm1d(h2), nn.ReLU(), nn.Dropout(0.1),
        nn.Linear(h2, 1),
    )

# ═══════════════════════════════════════════════════════════
# Per-label baseline training (shared logic)
# ═══════════════════════════════════════════════════════════
def train_per_label(seed=42, n_splits=5, epochs=200, patience=30,
                    online_aug_fn=None, name="Baseline"):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True; torch.backends.cudnn.benchmark = False
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    all_data, features, labels, label_strs = load_data()
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    fold_results = []

    for fold, (train_idx, val_idx) in enumerate(skf.split(all_data, label_strs)):
        train_features, train_labels = features[train_idx], labels[train_idx]
        val_features, val_labels = features[val_idx], labels[val_idx]
        all_val_probs = np.zeros((len(val_idx), 5))

        for li in range(5):
            torch.manual_seed(seed + fold * 100 + li * 7)
            np.random.seed(seed + fold * 100 + li * 7)
            random.seed(seed + fold * 100 + li * 7)
            tr_f = torch.tensor(train_features, dtype=torch.float32)
            tr_l = torch.tensor(train_labels[:, li:li+1], dtype=torch.float32)
            va_f = torch.tensor(val_features, dtype=torch.float32)
            va_l = torch.tensor(val_labels[:, li:li+1], dtype=torch.float32)
            train_loader = DataLoader(TensorDataset(tr_f, tr_l), batch_size=32, shuffle=True, drop_last=True)
            val_loader = DataLoader(TensorDataset(va_f, va_l), batch_size=32)
            model = HerbModel(num_labels=1).to(device)
            criterion = AsymmetricLoss(gamma_neg=4, gamma_pos=1, clip=0.05)
            optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=5e-4)
            scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs, eta_min=1e-6)
            best_auc, cnt, best_state = 0.0, 0, None
            for epoch in range(epochs):
                model.train()
                for fv, lb in train_loader:
                    fv, lb = fv.to(device), lb.to(device)
                    if online_aug_fn is not None:
                        fv = online_aug_fn(fv)
                    fv, lb = mixup_batch(fv, lb, alpha=0.2)
                    lb = lb * 0.95 + 0.025
                    loss = criterion(model(fv), lb)
                    optimizer.zero_grad(); loss.backward()
                    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0); optimizer.step()
                scheduler.step()
                model.eval()
                vps, vls = [], []
                with torch.no_grad():
                    for fv, lb in val_loader:
                        vps.append(torch.sigmoid(model(fv.to(device))).cpu().numpy()); vls.append(lb.numpy())
                vp, vl = np.concatenate(vps), np.concatenate(vls)
                try: va = roc_auc_score(vl, vp)
                except: va = 0.0
                if va > best_auc: best_auc=va; cnt=0; best_state={k:v.clone() for k,v in model.state_dict().items()}
                else: cnt+=1
                if cnt>=patience: break
            if best_state: model.load_state_dict(best_state)
            model.eval()
            vps=[]
            with torch.no_grad():
                for fv,_ in val_loader: vps.append(torch.sigmoid(model(fv.to(device))).cpu().numpy())
            all_val_probs[:,li] = np.concatenate(vps).flatten()

        try: fold_auc = roc_auc_score(val_labels, all_val_probs, average='macro')
        except: fold_auc = 0.0
        fold_results.append(fold_auc)

    m, s = np.mean(fold_results), np.std(fold_results)
    print(f"  {name}: AUC = {m:.4f} +/- {s:.4f}")
    return m, s, fold_results


# ═══════════════════════════════════════════════════════════
# Joint multi-label training
# ═══════════════════════════════════════════════════════════
def train_joint(model_cls, name, seed=42, n_splits=5, epochs=200, patience=30):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True; torch.backends.cudnn.benchmark = False
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    all_data, features, labels, label_strs = load_data()
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    fold_results = []

    for fold, (train_idx, val_idx) in enumerate(skf.split(all_data, label_strs)):
        torch.manual_seed(seed + fold * 100)
        np.random.seed(seed + fold * 100)
        random.seed(seed + fold * 100)
        tr_f = torch.tensor(features[train_idx], dtype=torch.float32)
        tr_l = torch.tensor(labels[train_idx], dtype=torch.float32)
        va_f = torch.tensor(features[val_idx], dtype=torch.float32)
        va_l = torch.tensor(labels[val_idx], dtype=torch.float32)
        train_loader = DataLoader(TensorDataset(tr_f, tr_l), batch_size=32, shuffle=True, drop_last=True)
        val_loader = DataLoader(TensorDataset(va_f, va_l), batch_size=32)
        model = model_cls().to(device)
        criterion = AsymmetricLoss(gamma_neg=4, gamma_pos=1, clip=0.05)
        optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=5e-4)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs, eta_min=1e-6)
        best_auc, counter, best_state = 0.0, 0, None
        for epoch in range(epochs):
            model.train()
            for fv, lb in train_loader:
                fv, lb = fv.to(device), lb.to(device)
                fv, lb = mixup_batch(fv, lb, alpha=0.2)
                lb = lb * 0.95 + 0.025
                loss = criterion(model(fv), lb)
                optimizer.zero_grad(); loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0); optimizer.step()
            scheduler.step()
            model.eval()
            vps, vls = [], []
            with torch.no_grad():
                for fv, lb in val_loader:
                    vps.append(torch.sigmoid(model(fv.to(device))).cpu().numpy()); vls.append(lb.numpy())
            vp, vl = np.concatenate(vps), np.concatenate(vls)
            try: val_auc=roc_auc_score(vl,vp,average='macro')
            except: val_auc=0.0
            if val_auc>best_auc: best_auc=val_auc; counter=0; best_state={k:v.clone() for k,v in model.state_dict().items()}
            else: counter+=1
            if counter>=patience: break
        if best_state: model.load_state_dict(best_state)
        model.eval()
        vps, vls = [], []
        with torch.no_grad():
            for fv, lb in val_loader:
                vps.append(torch.sigmoid(model(fv.to(device))).cpu().numpy()); vls.append(lb.numpy())
        vp, vl = np.concatenate(vps), np.concatenate(vls)
        try: auc=roc_auc_score(vl,vp,average='macro')
        except: auc=0.0
        fold_results.append(auc)

    m,s = np.mean(fold_results), np.std(fold_results)
    print(f"  {name}: AUC = {m:.4f} +/- {s:.4f}")
    return m, s

# ═══════════════════════════════════════════════════════════
# Label correlation models
# ═══════════════════════════════════════════════════════════
class GroupedModel(nn.Module):
    def __init__(self, feat_dim=300):
        super().__init__()
        self.shared_enc = nn.Sequential(
            nn.Linear(feat_dim, 512), nn.BatchNorm1d(512), nn.ReLU(), nn.Dropout(0.2),
            nn.Linear(512, 256), nn.BatchNorm1d(256), nn.ReLU(), nn.Dropout(0.1))
        self.head_l1 = nn.Linear(256, 1)
        self.head_l2 = nn.Linear(256, 1)
        self.ind_l0 = make_head(feat_dim)
        self.ind_l3 = make_head(feat_dim)
        self.ind_l4 = make_head(feat_dim)
    def forward(self, x):
        shared = self.shared_enc(x)
        return torch.cat([self.ind_l0(x), self.head_l1(shared), self.head_l2(shared),
                          self.ind_l3(x), self.ind_l4(x)], dim=1)

class CrossStitchModel(nn.Module):
    def __init__(self, feat_dim=300):
        super().__init__()
        self.enc1 = nn.ModuleList([nn.Sequential(
            nn.Linear(feat_dim, 512), nn.BatchNorm1d(512), nn.ReLU(), nn.Dropout(0.2)) for _ in range(5)])
        self.enc2 = nn.ModuleList([nn.Sequential(
            nn.Linear(512, 256), nn.BatchNorm1d(256), nn.ReLU(), nn.Dropout(0.1)) for _ in range(5)])
        self.heads = nn.ModuleList([nn.Linear(256, 1) for _ in range(5)])
        self.stitch = nn.Parameter(torch.eye(5) * 0.9 + torch.ones(5, 5) * 0.02)
    def forward(self, x):
        h1 = torch.stack([enc(x) for enc in self.enc1], dim=1)
        alpha = torch.softmax(self.stitch, dim=1)
        h1_mixed = torch.einsum('ij,bjd->bid', alpha, h1)
        h2 = [self.enc2[i](h1_mixed[:, i]) for i in range(5)]
        return torch.cat([self.heads[i](h2[i]) for i in range(5)], dim=1)

class LabelAttnModel(nn.Module):
    def __init__(self, feat_dim=300, enc_dim=256):
        super().__init__()
        self.encoders = nn.ModuleList([nn.Sequential(
            nn.Linear(feat_dim, 512), nn.BatchNorm1d(512), nn.ReLU(), nn.Dropout(0.2),
            nn.Linear(512, enc_dim), nn.BatchNorm1d(enc_dim), nn.ReLU(), nn.Dropout(0.1)) for _ in range(5)])
        self.attn = nn.MultiheadAttention(enc_dim, num_heads=4, dropout=0.1, batch_first=True)
        self.heads = nn.ModuleList([nn.Linear(enc_dim, 1) for _ in range(5)])
    def forward(self, x):
        feats = torch.stack([enc(x) for enc in self.encoders], dim=1)
        attn_out, _ = self.attn(feats, feats, feats)
        combined = feats + attn_out
        return torch.cat([self.heads[i](combined[:, i]) for i in range(5)], dim=1)


# ═══════════════════════════════════════════════════════════
# Post-hoc correction
# ═══════════════════════════════════════════════════════════
def posthoc_correction(fold_results_list, all_fold_probs, all_fold_labels):
    """Apply fixed-alpha post-hoc correction and return best."""
    best_m, best_alpha = 0, 0
    for alpha in [0.05, 0.10, 0.15, 0.20, 0.25]:
        fold_aucs = []
        for fold in range(5):
            vp = all_fold_probs[fold]
            vl = all_fold_labels[fold]
            corrected = np.zeros_like(vp)
            for li in range(5):
                corr_row = np.clip(CORR[li].copy(), 0, 1)
                corr_row[li] = 0
                total = corr_row.sum()
                if total > 0:
                    neighbor_avg = (vp * corr_row[None,:]).sum(axis=1) / total
                    corrected[:, li] = (1-alpha)*vp[:, li] + alpha*neighbor_avg
                else:
                    corrected[:, li] = vp[:, li]
            try: auc = roc_auc_score(vl, corrected, average='macro')
            except: auc = 0.0
            fold_aucs.append(auc)
        m = np.mean(fold_aucs)
        if m > best_m:
            best_m = m; best_alpha = alpha
    s = np.std(fold_aucs)
    return best_m, s, best_alpha


# ═══════════════════════════════════════════════════════════
# Online augmentation functions
# ═══════════════════════════════════════════════════════════
def online_drop(drop_prob):
    def fn(x):
        mask = (torch.rand_like(x) > drop_prob).float()
        return x * mask
    return fn

def online_drop_add(drop_prob, add_prob):
    def fn(x):
        mask = (torch.rand_like(x) > drop_prob).float()
        x = x * mask
        add_mask = (torch.rand_like(x) < add_prob) & (x == 0)
        x = torch.clamp(x + add_mask.float(), 0, 1)
        return x
    return fn


# ═══════════════════════════════════════════════════════════
# SMOTE for binary features
# ═══════════════════════════════════════════════════════════
def smote_binary(X, y, n_synthetic=50, k=5):
    from sklearn.neighbors import NearestNeighbors
    pos_idx = np.where(y == 1)[0]
    neg_idx = np.where(y == 0)[0]
    if len(pos_idx) <= len(neg_idx):
        minority_X, minority_label = X[pos_idx], 1
    else:
        minority_X, minority_label = X[neg_idx], 0
    if len(minority_X) < k + 1: k = max(1, len(minority_X) - 1)
    nn = NearestNeighbors(n_neighbors=k + 1); nn.fit(minority_X)
    _, indices = nn.kneighbors(minority_X)
    synthetic_X = []
    for _ in range(n_synthetic):
        i = np.random.randint(len(minority_X))
        j = indices[i, np.random.randint(1, k + 1)]
        lam = np.random.rand()
        new = (lam * minority_X[i] + (1 - lam) * minority_X[j] > 0.5).astype(np.float32)
        synthetic_X.append(new)
    if not synthetic_X: return X, y
    synthetic_X = np.array(synthetic_X)
    synthetic_y = np.full(len(synthetic_X), minority_label, dtype=np.float32)
    return np.concatenate([X, synthetic_X]), np.concatenate([y, synthetic_y])


def train_per_label_smote(n_synthetic, name, seed=42, n_splits=5, epochs=200, patience=30):
    """Per-label with SMOTE offline augmentation."""
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True; torch.backends.cudnn.benchmark = False
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    all_data, features, labels, label_strs = load_data()
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    fold_results = []

    for fold, (train_idx, val_idx) in enumerate(skf.split(all_data, label_strs)):
        train_features, train_labels = features[train_idx], labels[train_idx]
        val_features, val_labels = features[val_idx], labels[val_idx]
        all_val_probs = np.zeros((len(val_idx), 5))
        for li in range(5):
            torch.manual_seed(seed + fold*100 + li*7)
            np.random.seed(seed + fold*100 + li*7)
            random.seed(seed + fold*100 + li*7)
            tr_X, tr_y = smote_binary(train_features.copy(), train_labels[:,li].copy(), n_synthetic=n_synthetic)
            tr_f = torch.tensor(tr_X, dtype=torch.float32)
            tr_l = torch.tensor(tr_y[:,None], dtype=torch.float32)
            va_f = torch.tensor(val_features, dtype=torch.float32)
            va_l = torch.tensor(val_labels[:,li:li+1], dtype=torch.float32)
            train_loader = DataLoader(TensorDataset(tr_f, tr_l), batch_size=32, shuffle=True, drop_last=True)
            val_loader = DataLoader(TensorDataset(va_f, va_l), batch_size=32)
            model = HerbModel(num_labels=1).to(device)
            criterion = AsymmetricLoss(gamma_neg=4, gamma_pos=1, clip=0.05)
            optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=5e-4)
            scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs, eta_min=1e-6)
            best_auc, cnt, best_state = 0.0, 0, None
            for epoch in range(epochs):
                model.train()
                for fv, lb in train_loader:
                    fv, lb = fv.to(device), lb.to(device)
                    fv, lb = mixup_batch(fv, lb, alpha=0.2)
                    lb = lb * 0.95 + 0.025
                    loss = criterion(model(fv), lb)
                    optimizer.zero_grad(); loss.backward()
                    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0); optimizer.step()
                scheduler.step()
                model.eval()
                vps, vls = [], []
                with torch.no_grad():
                    for fv, lb in val_loader:
                        vps.append(torch.sigmoid(model(fv.to(device))).cpu().numpy()); vls.append(lb.numpy())
                vp, vl = np.concatenate(vps), np.concatenate(vls)
                try: va = roc_auc_score(vl, vp)
                except: va = 0.0
                if va > best_auc: best_auc=va; cnt=0; best_state={k:v.clone() for k,v in model.state_dict().items()}
                else: cnt+=1
                if cnt>=patience: break
            if best_state: model.load_state_dict(best_state)
            model.eval()
            vps=[]
            with torch.no_grad():
                for fv,_ in val_loader: vps.append(torch.sigmoid(model(fv.to(device))).cpu().numpy())
            all_val_probs[:,li] = np.concatenate(vps).flatten()
        try: fold_auc = roc_auc_score(val_labels, all_val_probs, average='macro')
        except: fold_auc = 0.0
        fold_results.append(fold_auc)
    m,s = np.mean(fold_results), np.std(fold_results)
    print(f"  {name}: AUC = {m:.4f} +/- {s:.4f}")
    return m, s


# ═══════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("="*60)
    print("ALL EXPERIMENTS — venv PyTorch 2.11.0")
    print("="*60)
    results = {}

    # Baseline
    print("\n--- Baseline ---")
    m, s, base_folds = train_per_label(name="Baseline")
    results['00_Baseline'] = (m, s)

    # ── LABEL CORRELATION ──────────────────────────────────
    print("\n--- Label correlation ---")

    print("[A] Grouped (L1+L2 shared)")
    m, s = train_joint(GroupedModel, "Grouped")
    results['A_Grouped'] = (m, s)

    print("[B] CrossStitch")
    m, s = train_joint(CrossStitchModel, "CrossStitch")
    results['B_CrossStitch'] = (m, s)

    print("[C] LabelAttn")
    m, s = train_joint(LabelAttnModel, "LabelAttn")
    results['C_LabelAttn'] = (m, s)

    # Post-hoc: collect baseline fold probs
    print("[D] Post-hoc correction (recomputing baseline probs)...")
    random.seed(42); np.random.seed(42); torch.manual_seed(42)
    torch.backends.cudnn.deterministic = True; torch.backends.cudnn.benchmark = False
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    all_data, features, labels, label_strs = load_data()
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    all_fold_probs, all_fold_labels = {}, {}
    for fold, (train_idx, val_idx) in enumerate(skf.split(all_data, label_strs)):
        train_features, train_labels_f = features[train_idx], labels[train_idx]
        val_features, val_labels_f = features[val_idx], labels[val_idx]
        val_probs = np.zeros((len(val_idx), 5))
        for li in range(5):
            torch.manual_seed(42 + fold*100 + li*7)
            np.random.seed(42 + fold*100 + li*7)
            random.seed(42 + fold*100 + li*7)
            tr_f = torch.tensor(train_features, dtype=torch.float32)
            tr_l = torch.tensor(train_labels_f[:,li:li+1], dtype=torch.float32)
            va_f = torch.tensor(val_features, dtype=torch.float32)
            va_l = torch.tensor(val_labels_f[:,li:li+1], dtype=torch.float32)
            train_loader = DataLoader(TensorDataset(tr_f, tr_l), batch_size=32, shuffle=True, drop_last=True)
            val_loader = DataLoader(TensorDataset(va_f, va_l), batch_size=32)
            model = HerbModel(num_labels=1).to(device)
            criterion = AsymmetricLoss(gamma_neg=4, gamma_pos=1, clip=0.05)
            optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=5e-4)
            scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=200, eta_min=1e-6)
            best_auc, cnt, best_state = 0.0, 0, None
            for epoch in range(200):
                model.train()
                for fv, lb in train_loader:
                    fv, lb = fv.to(device), lb.to(device)
                    fv, lb = mixup_batch(fv, lb, alpha=0.2)
                    lb = lb * 0.95 + 0.025
                    loss = criterion(model(fv), lb)
                    optimizer.zero_grad(); loss.backward()
                    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0); optimizer.step()
                scheduler.step()
                model.eval()
                vps, vls = [], []
                with torch.no_grad():
                    for fv, lb in val_loader:
                        vps.append(torch.sigmoid(model(fv.to(device))).cpu().numpy()); vls.append(lb.numpy())
                vp, vl = np.concatenate(vps), np.concatenate(vls)
                try: va = roc_auc_score(vl, vp)
                except: va = 0.0
                if va > best_auc: best_auc=va; cnt=0; best_state={k:v.clone() for k,v in model.state_dict().items()}
                else: cnt+=1
                if cnt>=30: break
            if best_state: model.load_state_dict(best_state)
            model.eval()
            vps=[]
            with torch.no_grad():
                for fv,_ in val_loader: vps.append(torch.sigmoid(model(fv.to(device))).cpu().numpy())
            val_probs[:,li] = np.concatenate(vps).flatten()
        all_fold_probs[fold] = val_probs
        all_fold_labels[fold] = val_labels_f

    best_m, best_s, best_alpha = posthoc_correction(base_folds, all_fold_probs, all_fold_labels)
    print(f"  PostHoc (best fixed alpha={best_alpha}): AUC = {best_m:.4f} +/- {best_s:.4f}")
    results['D_PostHoc'] = (best_m, best_s)

    # ── DATA AUGMENTATION ──────────────────────────────────
    print("\n--- Data augmentation ---")

    print("[E] SMOTE 50")
    m, s = train_per_label_smote(50, "SMOTE_50")
    results['E_SMOTE_50'] = (m, s)

    print("[F] SMOTE 100")
    m, s = train_per_label_smote(100, "SMOTE_100")
    results['F_SMOTE_100'] = (m, s)

    print("[G] Online dropout 15%")
    m, s, _ = train_per_label(online_aug_fn=online_drop(0.15), name="OnlineDrop_15")
    results['G_OnlineDrop_15'] = (m, s)

    print("[H] Online dropout 30%")
    m, s, _ = train_per_label(online_aug_fn=online_drop(0.30), name="OnlineDrop_30")
    results['H_OnlineDrop_30'] = (m, s)

    print("[I] Online drop 15% + add 1%")
    m, s, _ = train_per_label(online_aug_fn=online_drop_add(0.15, 0.01), name="DropAdd_15_1")
    results['I_DropAdd_15_1'] = (m, s)

    print("[J] Online drop 10% + add 0.5%")
    m, s, _ = train_per_label(online_aug_fn=online_drop_add(0.10, 0.005), name="DropAdd_10_05")
    results['J_DropAdd_10_05'] = (m, s)

    print("[K] Online drop 20% + add 1%")
    m, s, _ = train_per_label(online_aug_fn=online_drop_add(0.20, 0.01), name="DropAdd_20_1")
    results['K_DropAdd_20_1'] = (m, s)

    # ── SUMMARY ────────────────────────────────────────────
    print("\n" + "="*60)
    print("SUMMARY")
    print("="*60)
    print(f"{'Method':<30} {'AUC':>10} {'± std':>10}")
    print("-"*50)
    for k, (m, s) in sorted(results.items()):
        marker = " ***" if m > results['00_Baseline'][0] + 0.001 else ""
        print(f"{k:<30} {m:>10.4f} {s:>10.4f}{marker}")
