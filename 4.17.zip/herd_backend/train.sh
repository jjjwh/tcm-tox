#!/bin/bash

GPU=0
BATCH=16

CUDA_VISIBLE_DEVICES=$GPU python train.py \
    --batch_size $BATCH \
    --gpu 0 \
    --epochs 50 \
    --lr 1e-3