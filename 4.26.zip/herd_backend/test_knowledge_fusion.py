"""
Test: which method of incorporating compound/target knowledge
causes the least drop (or even improves) vs baseline ProtoNet (AUC=0.6522).

Methods tested:
1. compound_multihot:   300d feat + 653d compound binary → ProtoNet(953d)
2. target_svd32:        300d feat + 32d target SVD       → ProtoNet(332d)
3. compound_svd32:      300d feat + 32d compound SVD     → ProtoNet(332d)
4. both_svd32:          300d feat + 32d comp SVD + 32d targ SVD → ProtoNet(364d)
5. interaction_stats:   300d feat + 8d hand-crafted stats → ProtoNet(308d)
6. dual_encoder_avg:    ProtoNet(300d feat) + ProtoNet(653d compound) → avg logits
7. knowledge_reg:       ProtoNet(300d) + compound similarity regularization
8. target_multihot:     300d feat + 1540d target binary   → ProtoNet(1840d)
"""

import os, random, json, numpy as np, torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import f1_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold
from sklearn.decomposition import TruncatedSVD

from model import AsymmetricLoss

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SEED = 42
N_SPLITS = 5


# ==================== Model Definitions ====================

class Encoder(nn.Module):
    def __init__(self, feat_dim=300):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(feat_dim, 512), nn.BatchNorm1d(512), nn.ReLU(), nn.Dropout(0.2),
            nn.Linear(512, 256), nn.BatchNorm1d(256), nn.ReLU(), nn.Dropout(0.1),
        )
    def forward(self, x):
        return self.net(x)


class ProtoNet(nn.Module):
    def __init__(self, feat_dim=300, proj_dim=64):
        super().__init__()
        self.encoder = Encoder(feat_dim)
        self.proj = nn.Linear(256, proj_dim)
        self.proto_pos = nn.Parameter(torch.randn(proj_dim) * 0.1)
        self.proto_neg = nn.Parameter(torch.randn(proj_dim) * 0.1)
        self.scale = nn.Parameter(torch.tensor(10.0))

    def forward(self, x, return_proj=False):
        h = self.encoder(x)
        z = F.normalize(self.proj(h), dim=1)
        pp = F.normalize(self.proto_pos.unsqueeze(0), dim=1)
        pn = F.normalize(self.proto_neg.unsqueeze(0), dim=1)
        sim_pos = (z * pp).sum(dim=1, keepdim=True)
        sim_neg = (z * pn).sum(dim=1, keepdim=True)
        logit = self.scale * (sim_pos - sim_neg)
        if return_proj:
            return logit, z
        return logit


class DualEncoderModel(nn.Module):
    """Two independent ProtoNets, average logits."""
    def __init__(self, feat_dim=300, know_dim=653, proj_dim=64):
        super().__init__()
        self.proto_feat = ProtoNet(feat_dim, proj_dim)
        self.proto_know = ProtoNet(know_dim, proj_dim)
        self.alpha = nn.Parameter(torch.tensor(0.7))  # learnable weight

    def forward(self, feat, know):
        logit_f = self.proto_feat(feat)
        logit_k = self.proto_know(know)
        a = torch.sigmoid(self.alpha)
        return a * logit_f + (1 - a) * logit_k


class ProtoNetWithReg(nn.Module):
    """ProtoNet on feat + knowledge similarity regularization on proj space."""
    def __init__(self, feat_dim=300, proj_dim=64):
        super().__init__()
        self.encoder = Encoder(feat_dim)
        self.proj = nn.Linear(256, proj_dim)
        self.proto_pos = nn.Parameter(torch.randn(proj_dim) * 0.1)
        self.proto_neg = nn.Parameter(torch.randn(proj_dim) * 0.1)
        self.scale = nn.Parameter(torch.tensor(10.0))

    def forward(self, x, return_proj=False):
        h = self.encoder(x)
        z = F.normalize(self.proj(h), dim=1)
        pp = F.normalize(self.proto_pos.unsqueeze(0), dim=1)
        pn = F.normalize(self.proto_neg.unsqueeze(0), dim=1)
        sim_pos = (z * pp).sum(dim=1, keepdim=True)
        sim_neg = (z * pn).sum(dim=1, keepdim=True)
        logit = self.scale * (sim_pos - sim_neg)
        if return_proj:
            return logit, z
        return logit


def knowledge_sim_loss(z, know_sim_matrix, indices):
    """Regularize: if two herbs share many compounds, their embeddings should be similar."""
    z_norm = F.normalize(z, dim=1)
    embed_sim = z_norm @ z_norm.T  # [B, B]
    target_sim = know_sim_matrix[indices][:, indices].to(z.device)
    loss = F.mse_loss(embed_sim, target_sim)
    return loss


# ==================== Utilities ====================

def find_best_thresholds(y_true, y_prob):
    thresholds = []
    for i in range(5):
        best_t, best_f1 = 0.5, 0
        for t in np.linspace(0.05, 0.9, 18):
            pred = (y_prob[:, i] > t).astype(int)
            f1 = f1_score(y_true[:, i], pred)
            if f1 > best_f1:
                best_f1, best_t = f1, t
        thresholds.append(best_t)
    return thresholds


def mixup_batch(fv, lb, alpha=0.2):
    if alpha <= 0:
        return fv, lb
    lam = np.random.beta(alpha, alpha)
    idx = torch.randperm(fv.size(0))
    return lam * fv + (1 - lam) * fv[idx], lam * lb + (1 - lam) * lb[idx]


def dropadd(fv):
    mask = (torch.rand_like(fv) > 0.20).float()
    fv = fv * mask
    add_mask = (torch.rand_like(fv) < 0.01) & (fv == 0)
    return torch.clamp(fv + add_mask.float(), 0, 1)


def set_seed(s):
    random.seed(s); np.random.seed(s); torch.manual_seed(s)
    torch.cuda.manual_seed_all(s)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


# ==================== Data Loading ====================

def load_data():
    with open(os.path.join(BASE_DIR, "dataset/output/all_herbs.json"), 'r', encoding='utf-8') as f:
        all_data = json.load(f)
    with open(os.path.join(BASE_DIR, "dataset/output/compound2id.json"), 'r') as f:
        c2id = json.load(f)
    with open(os.path.join(BASE_DIR, "dataset/output/target2id.json"), 'r') as f:
        t2id = json.load(f)

    n_compounds = len(c2id)
    n_targets = len(t2id)

    features = np.array([d["feature_vector"] for d in all_data], dtype=np.float32)
    labels = np.array([d["label"] for d in all_data], dtype=np.float32)

    # Build compound multi-hot (252, 653)
    compound_mh = np.zeros((len(all_data), n_compounds), dtype=np.float32)
    for i, d in enumerate(all_data):
        for cid in d["compound_ids"]:
            compound_mh[i, cid] = 1.0

    # Build target multi-hot (252, 1540)
    target_mh = np.zeros((len(all_data), n_targets), dtype=np.float32)
    for i, d in enumerate(all_data):
        for tid in d["target_ids"]:
            target_mh[i, tid] = 1.0

    # Build interaction statistics (8d)
    interaction_stats = np.zeros((len(all_data), 8), dtype=np.float32)
    for i, d in enumerate(all_data):
        mat = np.array(d["interaction_matrix"], dtype=np.float32)
        n_comp = len(d["compound_ids"])
        n_targ = len(d["target_ids"])
        total = mat.sum()
        density = total / max(mat.size, 1)
        comp_degree = mat.sum(axis=1)
        targ_degree = mat.sum(axis=0)
        interaction_stats[i] = [
            n_comp, n_targ, total, density,
            comp_degree.mean() if len(comp_degree) > 0 else 0,
            comp_degree.std() if len(comp_degree) > 1 else 0,
            targ_degree.mean() if len(targ_degree) > 0 else 0,
            targ_degree.std() if len(targ_degree) > 1 else 0,
        ]
    # Normalize interaction stats to [0,1]
    for col in range(8):
        col_min, col_max = interaction_stats[:, col].min(), interaction_stats[:, col].max()
        if col_max > col_min:
            interaction_stats[:, col] = (interaction_stats[:, col] - col_min) / (col_max - col_min)

    label_strs = [''.join(str(int(v)) for v in d['label']) for d in all_data]

    return features, labels, compound_mh, target_mh, interaction_stats, label_strs


# ==================== Training ====================

def train_one_config(config_name, features, labels, compound_mh, target_mh,
                     interaction_stats, label_strs):
    print(f"\n{'#'*70}")
    print(f"# Config: {config_name}")
    print(f"{'#'*70}")

    set_seed(SEED)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    skf = StratifiedKFold(n_splits=N_SPLITS, shuffle=True, random_state=SEED)
    fold_results = []

    for fold, (train_idx, val_idx) in enumerate(skf.split(features, label_strs)):
        print(f"\n  Fold {fold+1}/{N_SPLITS}")
        train_features, val_features = features[train_idx], features[val_idx]
        train_labels, val_labels = labels[train_idx], labels[val_idx]

        # Prepare knowledge features based on config
        if config_name == "compound_multihot":
            train_f = np.concatenate([train_features, compound_mh[train_idx]], axis=1)
            val_f = np.concatenate([val_features, compound_mh[val_idx]], axis=1)
            feat_dim = train_f.shape[1]
        elif config_name == "target_multihot":
            train_f = np.concatenate([train_features, target_mh[train_idx]], axis=1)
            val_f = np.concatenate([val_features, target_mh[val_idx]], axis=1)
            feat_dim = train_f.shape[1]
        elif config_name == "compound_svd32":
            svd = TruncatedSVD(n_components=32, random_state=SEED)
            comp_svd_train = svd.fit_transform(compound_mh[train_idx])
            comp_svd_val = svd.transform(compound_mh[val_idx])
            train_f = np.concatenate([train_features, comp_svd_train], axis=1)
            val_f = np.concatenate([val_features, comp_svd_val], axis=1)
            feat_dim = train_f.shape[1]
        elif config_name == "target_svd32":
            svd = TruncatedSVD(n_components=32, random_state=SEED)
            targ_svd_train = svd.fit_transform(target_mh[train_idx])
            targ_svd_val = svd.transform(target_mh[val_idx])
            train_f = np.concatenate([train_features, targ_svd_train], axis=1)
            val_f = np.concatenate([val_features, targ_svd_val], axis=1)
            feat_dim = train_f.shape[1]
        elif config_name == "both_svd32":
            svd_c = TruncatedSVD(n_components=32, random_state=SEED)
            svd_t = TruncatedSVD(n_components=32, random_state=SEED)
            c_train = svd_c.fit_transform(compound_mh[train_idx])
            c_val = svd_c.transform(compound_mh[val_idx])
            t_train = svd_t.fit_transform(target_mh[train_idx])
            t_val = svd_t.transform(target_mh[val_idx])
            train_f = np.concatenate([train_features, c_train, t_train], axis=1)
            val_f = np.concatenate([val_features, c_val, t_val], axis=1)
            feat_dim = train_f.shape[1]
        elif config_name == "interaction_stats":
            # Normalize stats only from train
            stats_train = interaction_stats[train_idx].copy()
            stats_val = interaction_stats[val_idx].copy()
            train_f = np.concatenate([train_features, stats_train], axis=1)
            val_f = np.concatenate([val_features, stats_val], axis=1)
            feat_dim = train_f.shape[1]
        elif config_name == "dual_encoder_compound":
            train_f = train_features
            val_f = val_features
            train_know = compound_mh[train_idx]
            val_know = compound_mh[val_idx]
            feat_dim = 300
        elif config_name == "knowledge_reg":
            train_f = train_features
            val_f = val_features
            feat_dim = 300
            # Build compound similarity matrix (Jaccard) from TRAIN only
            comp_train = compound_mh[train_idx]
            intersection = comp_train @ comp_train.T
            row_sum = comp_train.sum(axis=1, keepdims=True)
            union = row_sum + row_sum.T - intersection
            comp_sim_train = intersection / np.maximum(union, 1)
            comp_sim_train = torch.tensor(comp_sim_train, dtype=torch.float32)
        else:
            raise ValueError(f"Unknown config: {config_name}")

        all_val_probs = np.zeros((len(val_idx), 5))

        for li in range(5):
            set_seed(SEED + fold * 100 + li * 7)

            tr_f = torch.tensor(train_f, dtype=torch.float32)
            tr_l = torch.tensor(train_labels[:, li:li+1], dtype=torch.float32)
            va_f = torch.tensor(val_f, dtype=torch.float32)
            va_l = torch.tensor(val_labels[:, li:li+1], dtype=torch.float32)

            if config_name == "dual_encoder_compound":
                tr_k = torch.tensor(train_know, dtype=torch.float32)
                va_k = torch.tensor(val_know, dtype=torch.float32)
                train_loader = DataLoader(
                    TensorDataset(tr_f, tr_k, tr_l), batch_size=32,
                    shuffle=True, drop_last=True)
                val_loader = DataLoader(
                    TensorDataset(va_f, va_k, va_l), batch_size=64)
                model = DualEncoderModel(feat_dim=300, know_dim=compound_mh.shape[1]).to(device)
            elif config_name == "knowledge_reg":
                # Store train indices for sim lookup
                train_loader = DataLoader(
                    TensorDataset(tr_f, tr_l, torch.arange(len(train_idx))),
                    batch_size=32, shuffle=True, drop_last=True)
                val_loader = DataLoader(
                    TensorDataset(va_f, va_l), batch_size=64)
                model = ProtoNetWithReg(feat_dim=feat_dim).to(device)
            else:
                train_loader = DataLoader(
                    TensorDataset(tr_f, tr_l), batch_size=32,
                    shuffle=True, drop_last=True)
                val_loader = DataLoader(
                    TensorDataset(va_f, va_l), batch_size=64)
                model = ProtoNet(feat_dim=feat_dim).to(device)

            criterion = AsymmetricLoss(gamma_neg=4, gamma_pos=1, clip=0.05)
            optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=5e-4)
            scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=200, eta_min=1e-6)

            best_auc, patience_counter, best_state = 0.0, 0, None

            for epoch in range(200):
                model.train()
                for batch in train_loader:
                    if config_name == "dual_encoder_compound":
                        fv, kv, lb = batch
                        fv, kv, lb = fv.to(device), kv.to(device), lb.to(device)
                        fv = dropadd(fv)
                        fv, lb = mixup_batch(fv, lb, alpha=0.2)
                        lb = lb * 0.95 + 0.025
                        loss = criterion(model(fv, kv), lb)
                    elif config_name == "knowledge_reg":
                        fv, lb, idxs = batch
                        fv, lb = fv.to(device), lb.to(device)
                        fv = dropadd(fv)
                        fv, lb = mixup_batch(fv, lb, alpha=0.2)
                        lb = lb * 0.95 + 0.025
                        logit, z = model(fv, return_proj=True)
                        cls_loss = criterion(logit, lb)
                        reg_loss = knowledge_sim_loss(z, comp_sim_train, idxs)
                        loss = cls_loss + 0.1 * reg_loss
                    else:
                        fv, lb = batch
                        fv, lb = fv.to(device), lb.to(device)
                        fv = dropadd(fv)
                        fv, lb = mixup_batch(fv, lb, alpha=0.2)
                        lb = lb * 0.95 + 0.025
                        loss = criterion(model(fv), lb)

                    optimizer.zero_grad()
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                    optimizer.step()
                    if hasattr(model, 'scale'):
                        model.scale.data.clamp_(1.0, 30.0)
                    if hasattr(model, 'proto_feat'):
                        model.proto_feat.scale.data.clamp_(1.0, 30.0)
                        model.proto_know.scale.data.clamp_(1.0, 30.0)

                scheduler.step()

                model.eval()
                vp_list, vl_list = [], []
                with torch.no_grad():
                    for batch in val_loader:
                        if config_name == "dual_encoder_compound":
                            fv, kv, lb = batch
                            p = torch.sigmoid(model(fv.to(device), kv.to(device))).cpu().numpy()
                        else:
                            fv = batch[0]
                            lb = batch[1]
                            p = torch.sigmoid(model(fv.to(device))).cpu().numpy()
                        vp_list.append(p); vl_list.append(lb.numpy())
                vp = np.concatenate(vp_list)
                vl = np.concatenate(vl_list)
                try:
                    val_auc = roc_auc_score(vl, vp)
                except ValueError:
                    val_auc = 0.0

                if val_auc > best_auc:
                    best_auc = val_auc
                    patience_counter = 0
                    best_state = {k: v.clone() for k, v in model.state_dict().items()}
                else:
                    patience_counter += 1
                if patience_counter >= 30:
                    break

            if best_state:
                model.load_state_dict(best_state)

            model.eval()
            vp_list = []
            with torch.no_grad():
                for batch in val_loader:
                    if config_name == "dual_encoder_compound":
                        fv, kv, _ = batch
                        p = torch.sigmoid(model(fv.to(device), kv.to(device))).cpu().numpy()
                    else:
                        fv = batch[0]
                        p = torch.sigmoid(model(fv.to(device))).cpu().numpy()
                    vp_list.append(p)
            all_val_probs[:, li] = np.concatenate(vp_list).flatten()
            print(f"    Label {li}: AUC={best_auc:.4f}")

        try:
            fold_auc = roc_auc_score(val_labels, all_val_probs, average='macro')
        except ValueError:
            fold_auc = 0.0
        thresholds = find_best_thresholds(val_labels, all_val_probs)
        best_preds = np.zeros_like(all_val_probs)
        for i in range(5):
            best_preds[:, i] = (all_val_probs[:, i] > thresholds[i]).astype(int)
        macro_f1 = f1_score(val_labels, best_preds, average='macro', zero_division=0)
        micro_f1 = f1_score(val_labels, best_preds, average='micro', zero_division=0)
        print(f"  Fold {fold+1}: AUC={fold_auc:.4f}  MacF1={macro_f1:.4f}  MicF1={micro_f1:.4f}")
        fold_results.append((fold_auc, macro_f1, micro_f1))

    aucs = [r[0] for r in fold_results]
    mf1s = [r[1] for r in fold_results]
    mif1s = [r[2] for r in fold_results]
    print(f"\n  => {config_name}: AUC={np.mean(aucs):.4f}±{np.std(aucs):.4f}  "
          f"MacF1={np.mean(mf1s):.4f}±{np.std(mf1s):.4f}  "
          f"MicF1={np.mean(mif1s):.4f}±{np.std(mif1s):.4f}")
    return config_name, np.mean(aucs), np.std(aucs), np.mean(mf1s), np.std(mf1s), np.mean(mif1s), np.std(mif1s)


# ==================== Main ====================

if __name__ == "__main__":
    features, labels, compound_mh, target_mh, inter_stats, label_strs = load_data()

    configs = [
        "compound_multihot",    # 300+653=953d concat
        "target_svd32",         # 300+32d SVD
        "compound_svd32",       # 300+32d SVD
        "both_svd32",           # 300+64d SVD
        "interaction_stats",    # 300+8d hand-crafted
        "dual_encoder_compound",# two ProtoNets, learnable avg
        "knowledge_reg",        # ProtoNet + compound sim regularization
        "target_multihot",      # 300+1540=1840d concat
    ]

    results = []
    for cfg in configs:
        r = train_one_config(cfg, features, labels, compound_mh, target_mh, inter_stats, label_strs)
        results.append(r)

    print(f"\n{'='*80}")
    print(f"{'Method':<25} {'AUC':>12} {'MacF1':>12} {'MicF1':>12}")
    print(f"{'-'*80}")
    print(f"{'ProtoNet (baseline)':<25} {'0.6522±0.023':>12} {'0.6488±0.026':>12} {'0.6571±0.026':>12}")
    for name, auc_m, auc_s, mf1_m, mf1_s, mif1_m, mif1_s in sorted(results, key=lambda x: -x[1]):
        auc_str = f"{auc_m:.4f}±{auc_s:.3f}"
        mf1_str = f"{mf1_m:.4f}±{mf1_s:.3f}"
        mif1_str = f"{mif1_m:.4f}±{mif1_s:.3f}"
        diff = auc_m - 0.6522
        sign = "+" if diff >= 0 else ""
        print(f"{name:<25} {auc_str:>12} {mf1_str:>12} {mif1_str:>12}  ({sign}{diff:.4f})")
    print(f"{'='*80}")
