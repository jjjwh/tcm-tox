import os
import random
import json
import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import f1_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold

from model import ProtoNet, AsymmetricLoss, knowledge_sim_loss

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def find_best_thresholds(y_true, y_prob):
    thresholds = []
    for i in range(5):
        best_t, best_f1 = 0.5, 0
        for t in np.linspace(0.05, 0.9, 18):
            pred = (y_prob[:, i] > t).astype(int)
            f1 = f1_score(y_true[:, i], pred)
            if f1 > best_f1:
                best_f1, best_t = f1, t
        thresholds.append(best_t)
    return thresholds

def mixup_batch(feature_vecs, labels, alpha=0.2):
    if alpha <= 0:
        return feature_vecs, labels
    lam = np.random.beta(alpha, alpha)
    idx = torch.randperm(feature_vecs.size(0))
    feature_vecs = lam * feature_vecs + (1 - lam) * feature_vecs[idx]
    labels = lam * labels + (1 - lam) * labels[idx]
    return feature_vecs, labels

def dropadd(fv):
    """Online feature augmentation: drop 20% + add 1%."""
    mask = (torch.rand_like(fv) > 0.20).float()
    fv = fv * mask
    add_mask = (torch.rand_like(fv) < 0.01) & (fv == 0)
    return torch.clamp(fv + add_mask.float(), 0, 1)


def train(seed: int = 42, n_splits: int = 5):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    all_json_path = os.path.join(BASE_DIR, "dataset/output/all_herbs.json")
    if not os.path.exists(all_json_path):
        print("[ERROR] all_herbs.json not found — run dataset/process.py first")
        return
    with open(all_json_path, 'r', encoding='utf-8') as f:
        all_data = json.load(f)
    with open(os.path.join(BASE_DIR, "dataset/output/compound2id.json"), 'r') as f:
        c2id = json.load(f)

    features = np.array([d["feature_vector"] for d in all_data], dtype=np.float32)
    labels   = np.array([d["label"] for d in all_data], dtype=np.float32)

    # Build compound multi-hot matrix for knowledge regularization
    n_compounds = len(c2id)
    compound_mh = np.zeros((len(all_data), n_compounds), dtype=np.float32)
    for i, d in enumerate(all_data):
        for cid in d["compound_ids"]:
            compound_mh[i, cid] = 1.0

    label_strs = [''.join(str(int(v)) for v in d['label']) for d in all_data]
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)

    fold_results = []

    for fold, (train_idx, val_idx) in enumerate(skf.split(all_data, label_strs)):
        print(f"\n{'='*60}")
        print(f"Fold {fold+1}/{n_splits}  (train={len(train_idx)}, val={len(val_idx)})")
        print(f"{'='*60}")

        train_features, train_labels = features[train_idx], labels[train_idx]
        val_features,   val_labels   = features[val_idx],   labels[val_idx]

        # Build compound Jaccard similarity matrix from train set
        comp_train = compound_mh[train_idx]
        intersection = comp_train @ comp_train.T
        row_sum = comp_train.sum(axis=1, keepdims=True)
        union = row_sum + row_sum.T - intersection
        comp_sim_train = torch.tensor(
            intersection / np.maximum(union, 1), dtype=torch.float32)

        # --- Per-label training: 5 independent prototype classifiers ---
        all_val_probs = np.zeros((len(val_idx), 5))

        for li in range(5):
            torch.manual_seed(seed + fold * 100 + li * 7)
            np.random.seed(seed + fold * 100 + li * 7)
            random.seed(seed + fold * 100 + li * 7)

            tr_f = torch.tensor(train_features, dtype=torch.float32)
            tr_l = torch.tensor(train_labels[:, li:li+1], dtype=torch.float32)
            va_f = torch.tensor(val_features, dtype=torch.float32)
            va_l = torch.tensor(val_labels[:, li:li+1], dtype=torch.float32)

            train_loader = DataLoader(
                TensorDataset(tr_f, tr_l, torch.arange(len(train_idx))),
                batch_size=32, shuffle=True, drop_last=True)
            val_loader   = DataLoader(TensorDataset(va_f, va_l), batch_size=64)

            model = ProtoNet().to(device)
            criterion = AsymmetricLoss(gamma_neg=4, gamma_pos=1, clip=0.05)
            optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=5e-4)
            scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=200, eta_min=1e-6)

            best_auc, patience_counter = 0.0, 0
            best_state = None

            for epoch in range(200):
                model.train()
                total_loss, num_batches = 0.0, 0

                for fv, lb, idxs in train_loader:
                    fv, lb = fv.to(device), lb.to(device)
                    fv = dropadd(fv)
                    fv, lb = mixup_batch(fv, lb, alpha=0.2)
                    lb = lb * 0.95 + 0.025
                    logit, z = model(fv, return_proj=True)
                    cls_loss = criterion(logit, lb)
                    reg_loss = knowledge_sim_loss(z, comp_sim_train, idxs)
                    loss = cls_loss + 0.1 * reg_loss
                    optimizer.zero_grad()
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                    optimizer.step()
                    model.scale.data.clamp_(1.0, 30.0)
                    total_loss += loss.item()
                    num_batches += 1

                scheduler.step()

                # Evaluate
                model.eval()
                vp_list, vl_list = [], []
                with torch.no_grad():
                    for fv, lb in val_loader:
                        p = torch.sigmoid(model(fv.to(device))).cpu().numpy()
                        vp_list.append(p); vl_list.append(lb.numpy())
                vp = np.concatenate(vp_list)
                vl = np.concatenate(vl_list)
                try:
                    val_auc = roc_auc_score(vl, vp)
                except ValueError:
                    val_auc = 0.0

                if val_auc > best_auc:
                    best_auc = val_auc
                    patience_counter = 0
                    best_state = {k: v.clone() for k, v in model.state_dict().items()}
                else:
                    patience_counter += 1

                if patience_counter >= 30:
                    break

            if best_state:
                model.load_state_dict(best_state)

            # Collect val probs
            model.eval()
            vp_list = []
            with torch.no_grad():
                for fv, _ in val_loader:
                    p = torch.sigmoid(model(fv.to(device))).cpu().numpy()
                    vp_list.append(p)
            all_val_probs[:, li] = np.concatenate(vp_list).flatten()

            print(f"  Label {li}: best AUC = {best_auc:.4f}")

        # --- Fold report ---
        try:
            fold_auc = roc_auc_score(val_labels, all_val_probs, average='macro')
        except ValueError:
            fold_auc = 0.0

        thresholds = find_best_thresholds(val_labels, all_val_probs)
        best_preds = np.zeros_like(all_val_probs)
        for i in range(5):
            best_preds[:, i] = (all_val_probs[:, i] > thresholds[i]).astype(int)

        macro_f1 = f1_score(val_labels, best_preds, average='macro', zero_division=0)
        micro_f1 = f1_score(val_labels, best_preds, average='micro', zero_division=0)

        print(f"\n  [Fold {fold+1} Best]  AUC: {fold_auc:.4f}  "
              f"Macro-F1: {macro_f1:.4f}  Micro-F1: {micro_f1:.4f}")
        fold_results.append((fold_auc, macro_f1, micro_f1))

    aucs      = [r[0] for r in fold_results]
    macro_f1s = [r[1] for r in fold_results]
    micro_f1s = [r[2] for r in fold_results]

    print(f"\n{'='*60}")
    print(f"{n_splits}-Fold CV Summary")
    print(f"{'='*60}")
    print(f"AUC      : {np.mean(aucs):.4f} ± {np.std(aucs):.4f}")
    print(f"Macro-F1 : {np.mean(macro_f1s):.4f} ± {np.std(macro_f1s):.4f}")
    print(f"Micro-F1 : {np.mean(micro_f1s):.4f} ± {np.std(micro_f1s):.4f}")


if __name__ == "__main__":
    train()